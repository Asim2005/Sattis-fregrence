<?php
// Simple script to test Admin login mechanics directly
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/backend/config/db.php';
require_once __DIR__ . '/backend/helpers/response.php';
require_once __DIR__ . '/backend/helpers/jwt.php';

echo "<h1>Login Diagnostic Script</h1><pre>";

try {
    echo "1. Attempting Database Connection...\n";
    $db = Database::getConnection();
    echo "SUCCESS: Connected to database.\n\n";

    echo "2. Simulating JWT Generation...\n";
    $email = 'adminsatish@gmail.com';
    $token = JWT::generate(['id' => 1, 'email' => $email, 'role' => 'admin']);
    echo "SUCCESS: Generated JWT token: $token\n\n";

    echo "3. Querying Users Table...\n";
    $stmt = $db->query("SELECT id, name, email, role FROM users LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "SUCCESS: Fetched users from database:\n";
    print_r($users);
    echo "\n";

    echo "4. Checking if admin@satish.com exists...\n";
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute(['admin@satish.com']);
    $user = $stmt->fetch();
    if ($user) {
        echo "SUCCESS: Found default admin user in DB.\n";
        echo "Password verification test:\n";
        if (password_verify('admin123', $user['password'])) {
            echo "-> Password 'admin123' VERIFIED successfully!\n";
        } else {
            echo "-> Password 'admin123' verification FAILED. Password hash in DB: " . $user['password'] . "\n";
        }
    } else {
        echo "WARNING: default admin user (admin@satish.com) NOT found in DB.\n";
    }

} catch (\Throwable $e) {
    echo "\n\nDIAGNOSTIC ERROR: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . " on line " . $e->getLine() . "\n";
    echo "Trace:\n" . $e->getTraceAsString() . "\n";
}
echo "</pre>";
